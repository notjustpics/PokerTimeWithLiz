﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PokerHand
{
    struct Card
    {
        static string values = "AKQJT98765432";
        static string suits = "shdc";

        public readonly int Value;
        public readonly int Suit;

        public Card(int value, int suit)
        {
            Value = value;
            Suit = suit;
        }

        public override string ToString()
        {
            return String.Format("{0}{1}", values[Value], suits[Suit]);
        }
    }

    class CardValueComparer : IEqualityComparer<Card>
    {
        public bool Equals(Card c1, Card c2)
        {
            return c1.Value == c2.Value;
        }

        public int GetHashCode(Card c)
        {
            return c.Value.GetHashCode();
        }
    }

    class Program
    {
        static string[] names1 = {"Ace", "King", "Queen", "Jack", "Ten", "Nine", "Eight", "Seven", "Six", "Five", "Four", "Three", "Two"};
        static string[] names2 = { "Aces", "Kings", "Queens", "Jacks", "Tens", "Nines", "Eights", "Sevens", "Sixes", "Fives", "Fours", "Threes", "Twos" };
        static string[] suits = { "Spades", "Hearts", "Diamonds", "Clubs" };

        static Card[] cards = new Card[7];
        static Random random = new Random();

        static void Main()
        {
            string yn;

            while (true)
            {
                Deal();
                AssessHand();

                do
                {
                    Console.Write("Another deal? Y/N   : ");
                    yn = Console.ReadLine().ToLower();
                }
                while (yn != "y" && yn != "n");

                if(yn == "n")
                {
                    Console.Write("Are you a gambler? Y/N   : ");
                    yn = Console.ReadLine().ToLower();
                    if(yn.ToLower() == "n")
                    {
                        Console.Write("You sure you want to quit this game? Y/N   : ");
                        yn = Console.ReadLine().ToLower();
                        if(yn.ToLower() == "y")
                        {
                            return;
                        }
                    }
                    else { return; }
                }

            }
        }

        static void Deal()
        {
            int value, suit;
            bool alreadyDrawn;
            int count = 0;

            while (count < 7)
            {
                value = random.Next(13);
                suit = random.Next(4);
                alreadyDrawn = false;

                for (int i = 0; i < count; i++)
                {
                    if (cards[i].Value == value && cards[i].Suit == suit)
                    {
                        alreadyDrawn = true;
                        break;
                    }
                }

                if (!alreadyDrawn)
                {
                    cards[count] = new Card(value, suit);
                    count++;
                }
            }

            Console.Write("Cards as dealt     : ");
            foreach (Card c in cards) Console.Write("{0} ", c);
            Console.WriteLine();
        }

        static void AssessHand()
        {
            // sort by multiple
            var groupings = from card in cards
                            group card by card.Value into g
                            orderby g.Count() descending, g.Key
                            select g;

            Console.Write("Sorted by multiple : ");

            foreach (var g in groupings)
            {
                foreach (Card c in g) Console.Write("{0} ", c);
            }

            Console.WriteLine();

            int handType = -1;
            string hand = null;

            // check for card multiples
            int count1 = groupings.First().Count();
            int count2 = groupings.ElementAt(1).Count();
            int value1 = groupings.First().Key;
            int value2 = groupings.ElementAt(1).Key;

            if (count1 == 4)
            {
                handType = 1;
                hand = "Four " + names2[value1];
            }
            else if (count1 == 3 && count2 >= 2)
            {
                handType = 2;
                hand = "Full House - " + names2[value1] + " and " + names2[value2];
            }
            else if (count1 == 3)
            {
                handType = 5;
                hand = "Three " + names2[value1];
            }
            else if (count1 == 2 && count2 == 2)
            {
                handType = 6;
                hand = "Two Pairs - " + names2[value1] + " and " + names2[value2];
            }
            else if (count1 == 2)
            {
                handType = 7;
                hand = "Pair of " + names2[value1];
            }
            else
            {
                handType = 8;
                hand = names1[value1] + " high";
            }

            // sort by value
            cards = (from card in cards orderby card.Value select card).ToArray();

            Console.Write("Sorted by value    : ");
            foreach (Card card in cards) Console.Write("{0} ", card);
            Console.WriteLine();

            // now check for straight
            Card[] distinctCards = cards.Distinct(new CardValueComparer()).ToArray(); // remove cards with duplicate values
            bool straight = false;

            if (distinctCards.Length >= 5)
            {
                for (int i = 0; i < distinctCards.Length - 4; i++)
                {
                    if (distinctCards[i].Value == distinctCards[i + 4].Value - 4)
                    {
                        if (handType > 4)
                        {
                            hand = names1[distinctCards[i].Value] + "-high Straight";
                            handType = 4;
                        }
                        straight = true;
                        break;
                    }
                }
            }

            // sort by suit
            groupings = from card in cards
                        group card by card.Suit into g
                        orderby g.Count() descending
                        select g;

            Console.Write("Sorted by suit     : ");

            foreach (var g in groupings)
            {
                foreach (Card c in g) Console.Write("{0} ", c);
            }

            Console.WriteLine();

            // now check for flush
            int count = groupings.First().Count();

            if (count >= 5)
            {
                int index = groupings.First().First().Value;
                int suit = groupings.First().Key;

                if (handType > 3)
                {
                    handType = 3;
                    hand = names1[index] + "-high Flush in " + suits[suit];
                }

                if (straight)
                {
                    // now check for straight flush        
                    Card[] flushCards = (from card in groupings.First() orderby card.Value select card).ToArray();

                    for (int i = 0; i < count - 4; i++)
                    {
                        if (flushCards[i].Value == flushCards[i + 4].Value - 4)
                        {
                            bool straightFlush = true;
                            int flushSuit = flushCards[i].Suit;

                            for (int j = i + 1; j < i + 5; j++)
                            {
                                if (flushSuit != flushCards[j].Suit)
                                {
                                    straightFlush = false;
                                    break;
                                }
                            }

                            if (straightFlush)
                            {
                                handType = 0;
                                hand = names1[flushCards[i].Value] + "-high Straight Flush in " + suits[flushCards[i].Suit];
                                break;
                            }
                        }
                    }
                }
            }

            Console.Write("Strongest hand     : ");
            Console.WriteLine(hand);
        }
    }
}
